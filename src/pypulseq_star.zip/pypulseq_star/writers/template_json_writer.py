"""Template JSON writer boundary."""
