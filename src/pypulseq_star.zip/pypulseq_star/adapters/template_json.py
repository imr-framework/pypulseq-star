"""Template JSON adapter boundary."""
