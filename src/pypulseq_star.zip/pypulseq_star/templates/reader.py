"""Template JSON reader boundary."""
