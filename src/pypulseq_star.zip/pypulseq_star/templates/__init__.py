"""GammaSTAR template JSON helpers."""
